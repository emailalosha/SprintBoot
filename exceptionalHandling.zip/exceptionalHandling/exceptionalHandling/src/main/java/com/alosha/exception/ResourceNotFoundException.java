package com.alosha.exception;

public class ResourceNotFoundException extends RuntimeException {

	public ResourceNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public ResourceNotFoundException(String message) {
		super(message);
	}
	
}
