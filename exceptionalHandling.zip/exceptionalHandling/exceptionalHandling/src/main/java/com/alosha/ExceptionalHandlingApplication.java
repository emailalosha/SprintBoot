package com.alosha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan("com.alosha")
@SpringBootApplication

public class ExceptionalHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionalHandlingApplication.class, args);
	}

}
