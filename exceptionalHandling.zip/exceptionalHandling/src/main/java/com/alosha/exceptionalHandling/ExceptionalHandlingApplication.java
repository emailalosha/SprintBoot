package com.alosha.exceptionalHandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionalHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionalHandlingApplication.class, args);
	}

}
