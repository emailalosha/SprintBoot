package com.alosha.exceptionalHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionalHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
